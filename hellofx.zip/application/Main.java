package application;

import java.io.File;
import java.util.List;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {
	// store any command-line arguments that were entered.
	// NOTE: this.getParameters().getRaw() will get these also
	private List<String> args;

	private static final int WINDOW_WIDTH = 900;
	private static final int WINDOW_HEIGHT = 600;
	private static final String APP_TITLE = "Hello World!";
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		// save args example
		args = this.getParameters().getRaw();

		// Main layout is Border Pane example (top,left,center,right,bottom)
        	BorderPane root = new BorderPane();

		// Add the vertical box to the center of the root pane
        	Label label = new Label("CS400 MyFirstJavaFX");
        	root.setTop(label);
        	
        // Add the ComboBox in the left panel of the root pane
        	ComboBox<String> comboBox = new ComboBox<String>();
        	comboBox.getItems().addAll(
        		    "Chocolate",
        		    "Vanilla",
        		    "Strawberry (Gross)"
        		);
        	root.setLeft(comboBox);
        	
        // Add image of my face to center of root pane
        	ImageView imageView = new ImageView();
        	File file = new File("Andrew.jpg");
        	Image image = new Image(file.toURI().toString());
            imageView.setImage(image);
            root.setCenter(imageView);
            
         // Add the button to bottom of root pane
            Button button = new Button("Done");
            root.setBottom(button);
            
            
         // Creates a vertical box and adds check boxes labeled 1-10 to the 
         // right side of root pane
        	VBox vbox = new VBox();
            for(int i = 1; i < 11; i++) {
            	CheckBox checkBox = new CheckBox("" + i);
            	vbox.getChildren().add(checkBox);
            }
            	root.setRight(vbox);
        	
		Scene mainScene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);

		// Add the stuff and set the primary stage
        	primaryStage.setTitle(APP_TITLE);
        	primaryStage.setScene(mainScene);
        	primaryStage.show();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		   launch(args);
	}
}